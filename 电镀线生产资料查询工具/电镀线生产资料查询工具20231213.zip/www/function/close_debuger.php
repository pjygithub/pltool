<?php

//关闭报错
// (通用，0——关闭，1——开启)
// 报错类型： 
// E_PARSE | E_ERROR | E_CORE_ERROR | E_COMPILE_ERROR | E_USER_ERROR ||  E_WARNING| E_STRICT | E_NOTICE 
ini_set("display_errors", "1");
error_reporting(E_PARSE | E_ERROR | E_CORE_ERROR | E_COMPILE_ERROR | E_USER_ERROR);
