<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <script src="../layui/layui.js"></script>
  <link rel="stylesheet" href="../layui//css/layui.css" media="all">
  <link rel="stylesheet" href="./css/style.css">
</head>
<?php
include(dirname(__DIR__) . '/module/common_config.php');
$machines_str = file_get_contents(dirname(__DIR__) . '/machines.config.json');
$machines_arr = json_decode($machines_str, true);

// 单个更改
function setConfig1($s, $e)
{
  $sfile = dirname(__DIR__) . '/module/common_config.php';
  $efile = dirname(__DIR__) . '/module/bak.common_config.php';
  copy($sfile, $efile);
  $content = file_get_contents($sfile);
  $content = str_replace("$s", "$e", $content);
  // var_dump($content);
  file_put_contents($sfile, $content);
}
if (
  $_POST['status_name'] != $status_name or
  !empty($_POST['status_name'])
) {
  setConfig1('$status_name = "' . urldecode($status_name) . '"', '$status_name = "' . $_POST['status_name'] . '"');
}
if (
  $_POST['status_password'] != $status_password or
  !empty($_POST['status_password'])
) {
  setConfig1('$status_password = "' . urldecode($status_password) . '"', '$status_password = "' . $_POST['status_password'] . '"');
}
if (
  $_POST['status_url'] != $status_url or
  !empty($_POST['status_url'])
) {
  setConfig1('$status_url = "' . urldecode($status_url) . '"', '$status_url = "' . $_POST['status_url'] . '"');
}
if (
  $_POST['echartShowTime'] != $echartShowTime or
  !empty($_POST['echartShowTime'])
) {
  setConfig1('$echartShowTime = ' . $echartShowTime . '', '$echartShowTime = ' . $_POST['echartShowTime'] . '');
}
if (
  $_POST['echartShowFloatNum'] != $echartShowFloatNum or
  !empty($_POST['echartShowFloatNum'])
) {
  setConfig1('$echartShowFloatNum = ' . $echartShowFloatNum . '', '$echartShowFloatNum = ' . $_POST['echartShowFloatNum'] . '');
}
// if (
//   $_POST['tableLicensekey'] != $tableLicensekey or
//   !empty($_POST['tableLicensekey'])
// ) {
//   setConfig1('$tableLicensekey = "' . $tableLicensekey . '"', '$tableLicensekey = "' . $_POST['tableLicensekey'] . '"');
// } else {
//   setConfig1('$tableLicensekey = "' . $tableLicensekey . '"', '$tableLicensekey = "' . $tableLicensekey . '"');
// }

// if (
//   $_POST['ebotime10'] != $ebotime10 or
//   !empty($_POST['ebotime10'])
// ) {
//   setConfig1('$ebotime10 = ' . urldecode($ebotime10) . '', '$ebotime10 = ' . $_POST['ebotime10'] . '');
// }
// if (
//   $_POST['ebotime12'] != $ebotime12 or
//   !empty($_POST['ebotime12'])
// ) {
//   setConfig1('$ebotime12 = ' . urldecode($ebotime12) . '', '$ebotime12 = ' . $_POST['ebotime12'] . '');
// }
// if (
//   $_POST['ebotime31'] != $ebotime31 or
//   !empty($_POST['ebotime31'])
// ) {
//   setConfig1('$ebotime31 = ' . urldecode($ebotime31) . '', '$ebotime31 = ' . $_POST['ebotime31'] . '');
// }
// if (
//   $_POST['ebotimeOther'] != $ebotimeOther or
//   !empty($_POST['ebotimeOther'])
// ) {
//   setConfig1('$ebotimeOther = ' . urldecode($ebotimeOther) . '', '$ebotimeOther = ' . $_POST['ebotimeOther'] . '');
// }
// if (
//   $_POST['ebotime38'] != $ebotime38 or
//   !empty($_POST['ebotime38'])
// ) {
//   setConfig1('$ebotime38 = ' . urldecode($ebotime38) . '', '$ebotime38 = ' . $_POST['ebotime38'] . '');
// }
// if (
//   $_POST['ebotimeRSA'] != $ebotimeRSA or
//   !empty($_POST['ebotimeRSA'])
// ) {
//   setConfig1('$ebotimeRSA = ' . urldecode($ebotimeRSA) . '', '$ebotimeRSA = ' . $_POST['ebotimeRSA'] . '');
// }

// 机台配置的修改
$macstr = "[";
for ($i = 0; $i < count($_POST['macid']); $i++) {
  if ($_POST['mactype'][$i] != "RSA") {
    if (abs($_POST['macEBOtime'][$i]) > 99) {
      echo '<script>
      var index = layer.alert("哈哈哈，你真调皮！😀不过还是给你保存啦。😉", {
                  icon: 6,
                  shadeClose: true,
                  zIndex:999,
                  title: "信息提示"
                }
      );
      </script>;';
    }
    if ($i == (count($_POST['macid']) - 1)) {
      $macstr = $macstr . '{
      "id":"' . $_POST['macid'][$i] . '",
      "type": "' . $_POST['mactype'][$i] . '",
      "host": "' . $_POST['machost'][$i] . '",
      "ip": "' . $_POST['macip'][$i] . '",
      "EBOtime": "' . $_POST['macEBOtime'][$i] . '",
      "DataLog": ' . $_POST['macDataLog'][$i] . ',
      "ErrorLog": ' . $_POST['macErrorLog'][$i] . ',
      "EventLog": ' . $_POST['macEventLog'][$i] . ',
      "StartStopLog": ' . $_POST['macStartStopLog'][$i] . ',
      "downtimelog": ' . $_POST['macdowntimelog'][$i] . ',
      "ParameterLog/Machine":' . $_POST['macParameterLog/Machine'][$i] . ',
      "ParameterLog/Product":' . $_POST['macParameterLog/Product'][$i] . '
      }';
    } else {
      $macstr = $macstr . '{
      "id":"' . $_POST['macid'][$i] . '",
      "type": "' . $_POST['mactype'][$i] . '",
      "host": "' . $_POST['machost'][$i] . '",
      "ip": "' . $_POST['macip'][$i] . '",
      "EBOtime": "' . $_POST['macEBOtime'][$i] . '",
      "DataLog": ' . $_POST['macDataLog'][$i] . ',
      "ErrorLog": ' . $_POST['macErrorLog'][$i] . ',
      "EventLog": ' . $_POST['macEventLog'][$i] . ',
      "StartStopLog": ' . $_POST['macStartStopLog'][$i] . ',
      "downtimelog": ' . $_POST['macdowntimelog'][$i] . ',
      "ParameterLog/Machine":' . $_POST['macParameterLog/Machine'][$i] . ',
      "ParameterLog/Product":' . $_POST['macParameterLog/Product'][$i] . '
      },
      ';
    }
  }
  if ($_POST['mactype'][$i] == "RSA") {
    if (abs($_POST['macEBOtime'][$i]) > 99) {
      echo '<script>
      var index = layer.alert("哈哈哈，你真调皮！😀不过还是给你保存啦。😉", {
                  icon: 6,
                  shadeClose: true,
                  zIndex:999,
                  title: "信息提示"
                }
      );
      </script>;';
    }
    $macstr = $macstr . '{
      "id":"' . $_POST['macid'][$i] . '",
      "type": "' . $_POST['mactype'][$i] . '",
      "host": "' . $_POST['machost'][$i] . '",
      "ip": "' . $_POST['macip'][$i] . '",
      "EBOtime": "' . $_POST['macEBOtime'][$i] . '",
      "Rsa": ' . $_POST['macDataLog'][$i] . ',
      "Alarm": ' . $_POST['macErrorLog'][$i] . ',
      "Stopline": ' . $_POST['macdowntimelog'][$i] . ',
      "ParametricModifierLog": ' . $_POST['macParameterLog/Product'][$i] . '
    }';
  }
}
// 固定字段
$macstr = $macstr . ',
{
      "id": "testKuaiji",
      "type": "测试",
      "host": "p.hexffffff.top",
      "ip": "localhost/www/csvtest/Kuaiji",
      "DataLog": 1,
      "EBOtime": "6",
      "ErrorLog": 1,
      "EventLog": 1,
      "StartStopLog": 1,
      "downtimelog": 1,
      "ParameterLog/Machine": 1,
      "ParameterLog/Product": 1
},
{
      "id": "testSRmanji",
      "type": "测试",
      "host": "p.hexffffff.top",
      "ip": "localhost/www/csvtest/MANJI",
      "EBOtime": "6",
      "DataLog": 1,
      "ErrorLog": 1,
      "EventLog": 1,
      "StartStopLog": 1,
      "downtimelog": 1,
      "ParameterLog/Machine": 1,
      "ParameterLog/Product": 1
},
{
      "id": "testME2",
      "type": "测试",
      "host": "p.hexffffff.top",
      "ip": "localhost/www/csvtest/ME2",
      "EBOtime": "6",
      "DataLog": 1,
      "ErrorLog": 1,
      "EventLog": 1,
      "StartStopLog": 1,
      "downtimelog": 1,
      "ParameterLog/Machine": 1,
      "ParameterLog/Product": 1
},
{
      "id": "testNiPdAu",
      "type": "测试",
      "host": "p.hexffffff.top",
      "ip": "localhost/www/csvtest/NIPDAU",
      "EBOtime": "6",
      "DataLog": 1,
      "ErrorLog": 1,
      "EventLog": 1,
      "StartStopLog": 1,
      "downtimelog": 1,
      "ParameterLog/Machine": 1,
      "ParameterLog/Product": 1
},
{
      "id": "testBOC",
      "type": "测试",
      "host": "p.hexffffff.top",
      "ip": "localhost/www/csvtest/BOC",
      "EBOtime": "6",
      "DataLog": 1,
      "ErrorLog": 1,
      "EventLog": 0,
      "StartStopLog": 0,
      "downtimelog": 0,
      "ParameterLog/Machine": 0,
      "ParameterLog/Product": 0
},
{
      "id": "testRSA",
      "type": "测试",
      "host": "p.hexffffff.top",
      "ip": "localhost/www/csvtest/RSA",
      "EBOtime": "6",
      "Rsa": 1,
      "Alarm": 1,
      "Stopline": 1,
      "ParametricModifierLog": 1
},
{
      "id": "test5#",
      "type": "测试",
      "host": "j.hexffffff.top",
      "ip": "localhost/www/csvtest/5",
      "EBOtime": "6",
      "DataLog": 1,
      "ErrorLog": 1,
      "EventLog": 1,
      "StartStopLog": 1,
      "downtimelog": 1,
      "ParameterLog/Machine": 1,
      "ParameterLog/Product": 1
},
{
      "id": "test8#",
      "type": "测试",
      "host": "j.hexffffff.top",
      "ip": "localhost/www/csvtest/8",
      "EBOtime": "6",
      "DataLog": 1,
      "ErrorLog": 1,
      "EventLog": 1,
      "StartStopLog": 1,
      "downtimelog": 1,
      "ParameterLog/Machine": 1,
      "ParameterLog/Product": 1
},
{
      "id": "test1#",
      "type": "测试",
      "host": "j.hexffffff.top",
      "ip": "localhost/www/csvtest/1",
      "EBOtime": "6",
      "DataLog": 1,
      "ErrorLog": 1,
      "EventLog": 1,
      "StartStopLog": 1,
      "downtimelog": 1,
      "ParameterLog/Machine": 1,
      "ParameterLog/Product": 1
}
]';
// echo $macstr;
file_put_contents(dirname(__DIR__) . '/machines.config.json', $macstr);
echo "<pre>";
// var_dump($_POST);
// echo "<script>alert('OK！');self.location=document.referrer;</script>";
echo "</pre>";
?>

<script>
  // 取消alert标题网址。
  (function() {
    window.alert = function(name) {
      var iframe = document.createElement("IFRAME");
      iframe.style.display = "none";
      iframe.setAttribute("src", 'data:text/plain');
      document.documentElement.appendChild(iframe);
      window.frames[0].window.alert(name);
      iframe.parentNode.removeChild(iframe);
    }
  })();
  // 提示框
  var index = layer.open({
    type: 1,
    title: '提示信息',
    area: 'auto',
    anim: 'slideDown',
    icon: 6,
    zIndex: 9,
    content: '<div style="padding:15px;font-size: 2rem;">设置已保存，正在跳转...</div>'
  });
  setInterval(function() {
    self.location = document.referrer;
  }, 2000);
</script>

<body>
</body>

</html>