<?
$DataLog_L3_OnOffPumpSpeed = array(
    "Time", "L3 Ag Current Off Time",
    "L3 Ag Current On Time",
    "L3 Ag Off Time",
    "L3 Ag On Time",
    "L3 Ag Plating Current Off Time",
    "L3 Ag Plating Current On Time",
    "L3 Ag Pump Speed (High)",
    "L3 Ag Pump Speed (Low)",
    "L3 Cu Off Time",
    "L3 Cu On Time",
    "L3 Ag Off Time",
    "L3 Ag On Time",
    "L3 Ag Pump Speed (High)",
    "L3 Ag Pump Speed (Low)",
    "L3 Cu Off Time",
    "L3 Cu On Time",
);
$nick_col = $DataLog_L3_OnOffPumpSpeed;
