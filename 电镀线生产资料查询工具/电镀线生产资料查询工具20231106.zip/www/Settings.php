<?php
// echo "设置<br>";
include(dirname(__DIR__) . '/www/module/common_config.php');
// include(dirname(__DIR__) . '/www/machines.config.json');
$machines_str = file_get_contents(dirname(__DIR__) . '/www/machines.config.json');
$machines_arr = json_decode($machines_str, true);
?>
<!DOCTYPE html>
<html lang="zh_cn">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>设置</title>

</head>
<style>
    * {
        font-size: 1rem;
    }

    input {
        padding-left: 10px;
    }

    input[type=text] {
        /* width: 26rem; */
        /* width: 30%; */
        height: 2rem;
        border: 0px;
        border-bottom: 1px solid #333;

    }

    input[type=number] {
        /* width: 26rem; */
        /* width: 30%; */
        height: 2rem;
        border: 0px;
        border-bottom: 1px solid #333;
    }

    .leftRight {
        width: 49.5%;
        /* position: absolute; */
        float: left;
    }

    .layui-btn {
        position: fixed;
        height: 36px;
        line-height: 36px;
        border: 1px solid transparent;
        padding: 0 18px;
        background-color: #009688;
        color: #fff;
        white-space: nowrap;
        text-align: center;
        font-size: 14px;
        border-radius: 20px;
        cursor: pointer;
        outline: 0;
        -webkit-appearance: none;
        transition: all .3s;
        -webkit-transition: all .3s;
        box-sizing: border-box;
        top: 0;
        left: 0;
    }

    table>tbody>tr>td {
        /* border: 1px solid red; */
        text-align: center;
    }
</style>

<body>
    <form action="./module/settings_func.php" method="post">
        <input type="submit" value="保存设置" class="layui-btn">
        <h2 style="margin-top:43px;">“状态显示”登录账户配置：</h2>
        <label for="status_name">登录账户：</label><input type="text" name="status_name" id="status_name" value="<?php echo urldecode($status_name) ?>"><label for="status_name"> 比如：aam-intl\p02public</label><br>
        <label for="status_password">账户密码：</label><input type="text" name="status_password" id="status_password" value="<?php echo urldecode($status_password) ?>"><label for="status_password"> 比如：P02369258147</label>
        <br>
        <label for="status_url">网页地址：</label><input type="text" name="status_url" id="status_url" value="<?php echo urldecode($status_url) ?>" style="width:28rem"><label for="status_url"> 比如：amcnts19.amcex.asmpt.com/PltLinestate/ViewState.aspx，不包括http://和https:// ！</label><br>
        <h2>显示优化设置：</h2>
        <label for="echartShowTime">图表默认显示长度（分钟）：</label><input type="number" name="echartShowTime" id="echartShowTime" value="<?php echo $echartShowTime ?>"><label for="echartShowTime"> 比如：450个数据点</label><br>
        <label for="echartShowFloatNum">图表显示小数位数：</label><input type="number" name="echartShowFloatNum" id="echartShowFloatNum" value="<?php echo $echartShowFloatNum ?>"><label for="echartShowFloatNum"> 比如：比如3位0.001，整数0</label><br>
        <!-- <label for="tableLicensekey">handsontable授权码：</label><input type="text" name="tableLicensekey" id="tableLicensekey" value="<?php echo urldecode($tableLicensekey) ?>" style="width:28rem">
        <br> -->
        <!-- <label for="Release">测试发布：</label><input type="text" name="Release" id="Release" value="<?php echo $Release ?>"><label for="Release">1为发行版，0为测试版</label><br> -->
        <h2>机台主机名和IP设置：</h2>

        <table>
            <tbody>
                <tr>
                    <td>机台号</td>
                    <td>主机名</td>
                    <td>IP地址</td>
                    <td>EBO更换间隔(小时)</td>
                    <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                    <td>机台号</td>
                    <td>主机名</td>
                    <td>IP地址</td>
                    <td>EBO更换间隔(小时)</td>
                </tr>
                <?php
                // 数组总个数
                $coun_mac = count($machines_arr);
                echo '<pre>';
                // var_dump($machines_arr);
                echo '</pre>';

                for ($i = 0; $i < $coun_mac; $i++) {
                    if ($machines_arr[$i]['type'] != "测试" and $machines_arr[$i]['type'] != "RSA") {
                        if ($machines_arr[$i]['id'] < 10 and strlen($machines_arr[$i]['id']) < 2) {
                            $machines_arr[$i]['id'] = "0" . $machines_arr[$i]['id'];
                        }
                        if ($i % 2 == 0) {
                ?>
                            <tr>
                                <td><? echo $machines_arr[$i]['id'] ?></td>
                                <td><input type="text" name="machost[]" value="<? echo $machines_arr[$i]['host'] ?>" style="width:12rem;"></td>
                                <td><input type="text" name="macip[]" value="<? echo $machines_arr[$i]['ip'] ?>" style="width:12rem;"></td>
                                <td>
                                    <input type="text" name="macEBOtime[]" value="<? echo $machines_arr[$i]['EBOtime'] ?>" style="width:8rem;">
                                    <input type="text" name="macid[]" value="<? echo $machines_arr[$i]['id'] ?>" hidden>
                                    <input type="text" name="mactype[]" value="<? echo $machines_arr[$i]['type'] ?>" hidden>
                                    <input type="text" name="macDataLog[]" value="<? echo $machines_arr[$i]['DataLog'] ?>" hidden>
                                    <input type="text" name="macErrorLog[]" value="<? echo $machines_arr[$i]['ErrorLog'] ?>" hidden>
                                    <input type="text" name="macEventLog[]" value="<? echo $machines_arr[$i]['EventLog'] ?>" hidden>
                                    <input type="text" name="macStartStopLog[]" value="<? echo $machines_arr[$i]['StartStopLog'] ?>" hidden>
                                    <input type="text" name="macdowntimelog[]" value="<? echo $machines_arr[$i]['downtimelog'] ?>" hidden>
                                    <input type="text" name="macParameterLog/Machine[]" value="<? echo $machines_arr[$i]['ParameterLog/Machine'] ?>" hidden>
                                    <input type="text" name="macParameterLog/Product[]" value="<? echo $machines_arr[$i]['ParameterLog/Product'] ?>" hidden>
                                </td>
                                <td>&nbsp;&nbsp;</td>
                                <td><? echo $machines_arr[$i + 1]['id'] ?></td>
                                <td><input type="text" name="machost[]" value="<? echo $machines_arr[$i + 1]['host'] ?>" style="width:12rem;"></td>
                                <td><input type="text" name="macip[]" value="<? echo $machines_arr[$i + 1]['ip'] ?>" style="width:12rem;"></td>
                                <td><input type="text" name="macEBOtime[]" value="<? echo $machines_arr[$i + 1]['EBOtime'] ?>" style="width:8rem;"><input type="text" name="macid[]" value="<? echo $machines_arr[$i + 1]['id'] ?>" hidden>
                                    <input type="text" name="mactype[]" value="<? echo $machines_arr[$i + 1]['type'] ?>" hidden>
                                    <input type="text" name="macDataLog[]" value="<? echo $machines_arr[$i + 1]['DataLog'] ?>" hidden>
                                    <input type="text" name="macErrorLog[]" value="<? echo $machines_arr[$i + 1]['ErrorLog'] ?>" hidden>
                                    <input type="text" name="macEventLog[]" value="<? echo $machines_arr[$i + 1]['EventLog'] ?>" hidden>
                                    <input type="text" name="macStartStopLog[]" value="<? echo $machines_arr[$i + 1]['StartStopLog'] ?>" hidden>
                                    <input type="text" name="macdowntimelog[]" value="<? echo $machines_arr[$i + 1]['downtimelog'] ?>" hidden>
                                    <input type="text" name="macParameterLog/Machine[]" value="<? echo $machines_arr[$i + 1]['ParameterLog/Machine'] ?>" hidden>
                                    <input type="text" name="macParameterLog/Product[]" value="<? echo $machines_arr[$i + 1]['ParameterLog/Product'] ?>" hidden>
                                </td>

                            </tr>
                        <?php }
                    }
                    if ($machines_arr[$i]['type'] == "RSA") {
                        // var_dump($machines_arr[$i]['id']);
                        ?>
                        <tr>
                            <td><? echo $machines_arr[$i]['id'] ?></td>
                            <td><input type="text" name="machost[]" value="<? echo $machines_arr[$i]['host'] ?>"></td>
                            <td><input type="text" name="macip[]" value="<? echo $machines_arr[$i]['ip'] ?>"></td>
                            <td><input type="text" name="macEBOtime[]" value="<? echo $machines_arr[$i]['EBOtime'] ?>" style="width:8rem;">
                                <input type="text" name="macid[]" value="<? echo $machines_arr[$i]['id'] ?>" hidden>
                                <input type="text" name="mactype[]" value="<? echo $machines_arr[$i]['type'] ?>" hidden>
                                <input type="text" name="macDataLog[]" value="<? echo $machines_arr[$i]['Rsa'] ?>" hidden>
                                <input type="text" name="macErrorLog[]" value="<? echo $machines_arr[$i]['Alarm'] ?>" hidden>
                                <!-- <input type="text" name="macEventLog[]" value="<? echo $machines_arr[$i]['EventLog'] ?>" hidden> -->
                                <!-- <input type="text" name="macStartStopLog[]" value="<? echo $machines_arr[$i]['StartStopLog'] ?>" hidden> -->
                                <input type="text" name="macdowntimelog[]" value="<? echo $machines_arr[$i]['Stopline'] ?>" hidden>
                                <!-- <input type="text" name="macParameterLog/Machine[]" value="<? echo $machines_arr[$i]['ParameterLog/Machine'] ?>" hidden> -->
                                <input type="text" name="macParameterLog/Product[]" value="<? echo $machines_arr[$i]['ParametricModifierLog'] ?>" hidden>
                            </td>
                        </tr>
            </tbody>
        </table>

<?php
                    }
                }
?>
<div style="height:10px">&nbsp;</div>
    </form>
</body>

</html>