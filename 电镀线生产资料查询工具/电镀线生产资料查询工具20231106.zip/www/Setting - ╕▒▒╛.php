<?php
// echo "设置<br>";
include(dirname(__DIR__) . '/www/module/common_config.php');
// include(dirname(__DIR__) . '/www/machines.config.json');
$machines_str = file_get_contents(dirname(__DIR__) . '/www/machines.config.json');
$machines_arr = json_decode($machines_str, true);
?>
<!DOCTYPE html>
<html lang="zh_cn">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>设置</title>
</head>
<style>
    * {
        font-size: 1rem;
    }

    input[type=text] {
        /* width: 26rem; */
        /* width: 30%; */
        height: 2rem;
        border: 0px;
        border-bottom: 1px solid #333;
    }

    .left {
        width: 48%;
        /* position: absolute; */
        float: left;
    }
</style>

<body>
    <form action="./module/setting_func.php" method="post">
        <input type="submit" value="保存设置">
        <h2>“状态显示”登录账户配置：</h2>
        <label for="status_name">登录账户：</label><input type="text" name="status_name" id="status_name" value="<?php echo urldecode($status_name) ?>"><label for="status_name">如：aam-intl\p02public</label><br>
        <label for="status_password">账户密码：</label><input type="text" name="status_password" id="status_password" value="<?php echo urldecode($status_password) ?>"><label for="status_password">如：P02369258147</label>
        <br>
        <label for="status_url">网页地址：</label><input type="text" name="status_url" id="status_url" value="<?php echo urldecode($status_url) ?>" style="width:26rem"><label for="status_url">如：amcnts19.amcex.asmpt.com/PltLinestate/ViewState.aspx，不包括http://和https:// ！</label><br>
        <h2>显示优化配置：</h2>
        <label for="echartShowTime">图表默认显示时间（分钟）：</label><input type="text" name="echartShowTime" id="echartShowTime" value="<?php echo $echartShowTime ?>"><label for="echartShowTime">如：450个数据点</label><br>
        <!-- <label for="Release">测试发布：</label><input type="text" name="Release" id="Release" value="<?php echo $Release ?>"><label for="Release">1为发行版，0为测试版</label><br> -->
        <h2>机台域名和IP设置：</h2>
        <?php
        // var_dump($machines_arr);
        for ($i = 0; $i < count($machines_arr); $i++) {
            // var_dump($i);
            if ($i % 2 == 0) {
                echo "<div class='left'>";
                if ($machines_arr[$i]['type'] != "测试") {
                    if ($machines_arr[$i] <= 10) {
                        echo '<label for="mac' . $machines_arr[$i]['id'] . '">#0' . $machines_arr[$i]['id'] . '域名：</label><input type="text" name="mac' . $machines_arr[$i]['id'] . 'host" id="mac' . $machines_arr[$i]['id'] . 'host" value="' . $machines_arr[$i]['host'] . '">IP：</label><input type="text" name="mac' . $machines_arr[$i]['id'] . 'ip" id="mac' . $machines_arr[$i]['id'] . 'ip" value="' . $machines_arr[$i]['ip'] . '"><br>';
                    } else {
                        echo '<label for="mac' . $machines_arr[$i]['id'] . '">#' . $machines_arr[$i]['id'] . '域名：</label><input type="text" name="mac' . $machines_arr[$i]['id'] . 'host" id="mac' . $machines_arr[$i]['id'] . 'host" value="' . $machines_arr[$i]['host'] . '">IP：</label><input type="text" name="mac' . $machines_arr[$i]['id'] . 'ip" id="mac' . $machines_arr[$i]['id'] . 'ip" value="' . $machines_arr[$i]['ip'] . '"><br>';
                    }
                }
                echo "</div>";
            } else {
                echo "<div class='right'>";
                if ($machines_arr[$i]['type'] != "测试") {
                    if ($machines_arr[$i] <= 10) {
                        echo '<label for="mac' . $machines_arr[$i]['id'] . '">#0' . $machines_arr[$i]['id'] . '域名：</label><input type="text" name="mac' . $machines_arr[$i]['id'] . 'host" id="mac' . $machines_arr[$i]['id'] . 'host" value="' . $machines_arr[$i]['host'] . '">IP：</label><input type="text" name="mac' . $machines_arr[$i]['id'] . 'ip" id="mac' . $machines_arr[$i]['id'] . 'ip" value="' . $machines_arr[$i]['ip'] . '"><br>';
                    } else {
                        echo '<label for="mac' . $machines_arr[$i]['id'] . '">#' . $machines_arr[$i]['id'] . '域名：</label><input type="text" name="mac' . $machines_arr[$i]['id'] . 'host" id="mac' . $machines_arr[$i]['id'] . 'host" value="' . $machines_arr[$i]['host'] . '">IP：</label><input type="text" name="mac' . $machines_arr[$i]['id'] . 'ip" id="mac' . $machines_arr[$i]['id'] . 'ip" value="' . $machines_arr[$i]['ip'] . '"><br>';
                    }
                }
                echo "</div>";
            }
        }
        ?>

    </form>
</body>

</html>