<?
$DataLog_L4_OnOffPumpSpeed = array(
    "Time",
    "L4 Ag Current Off Time",
    "L4 Ag Current On Time",
    "L4 Ag Pump Speed (High)",
    "L4 Ag Pump Speed (Low)",
);
$nick_col = $DataLog_L4_OnOffPumpSpeed;
