<?php
// echo "设置<br>";
include(dirname(__DIR__) . '/www/module/common_config.php');
// include(dirname(__DIR__) . '/www/machines.config.json');
$machines_str = file_get_contents(dirname(__DIR__) . '/www/machines.config.json');
$machines_arr = json_decode($machines_str, true);
?>
<!DOCTYPE html>
<html lang="zh_cn">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>设置</title>

</head>
<style>
    * {
        font-size: 1rem;
    }

    input {
        padding-left: 10px;
    }

    input[type=text] {
        /* width: 26rem; */
        /* width: 30%; */
        height: 2rem;
        border: 0px;
        border-bottom: 1px solid #333;
    }

    input[type=number] {
        /* width: 26rem; */
        /* width: 30%; */
        height: 2rem;
        border: 0px;
        border-bottom: 1px solid #333;
    }

    .leftRight {
        width: 49.5%;
        /* position: absolute; */
        float: left;
    }

    .layui-btn {
        position: fixed;
        height: 36px;
        line-height: 36px;
        border: 1px solid transparent;
        padding: 0 18px;
        background-color: #009688;
        color: #fff;
        white-space: nowrap;
        text-align: center;
        font-size: 14px;
        border-radius: 20px;
        cursor: pointer;
        outline: 0;
        -webkit-appearance: none;
        transition: all .3s;
        -webkit-transition: all .3s;
        box-sizing: border-box;
        top: 0;
        left: 0;
    }
</style>

<body>
    <form action="./module/settings_func.php" method="post">
        <input type="submit" value="保存设置" class="layui-btn">
        <h2 style="margin-top:43px;">“状态显示”登录账户配置：</h2>
        <label for="status_name">登录账户：</label><input type="text" name="status_name" id="status_name" value="<?php echo urldecode($status_name) ?>"><label for="status_name"> 比如：aam-intl\p02public</label><br>
        <label for="status_password">账户密码：</label><input type="text" name="status_password" id="status_password" value="<?php echo urldecode($status_password) ?>"><label for="status_password"> 比如：P02369258147</label>
        <br>
        <label for="status_url">网页地址：</label><input type="text" name="status_url" id="status_url" value="<?php echo urldecode($status_url) ?>" style="width:28rem"><label for="status_url"> 比如：amcnts19.amcex.asmpt.com/PltLinestate/ViewState.aspx，不包括http://和https:// ！</label><br>
        <h2>显示优化设置：</h2>
        <label for="echartShowTime">图表默认显示长度（分钟）：</label><input type="number" name="echartShowTime" id="echartShowTime" value="<?php echo $echartShowTime ?>"><label for="echartShowTime"> 比如：450个数据点</label><br>
        <label for="ebotime10">#10 EBO换药间隔时间（小时）：</label><input type="text" name="ebotime10" id="ebotime10" value="<?php echo $ebotime10 ?>"><label for="ebotime10"> 比如：2.5，可输入范围：0 ~ 999999999</label><br>
        <label for="ebotime12">#12 EBO换药间隔时间（小时）：</label><input type="text" name="ebotime12" id="ebotime12" value="<?php echo $ebotime12 ?>"><label for="ebotime12"> 比如：6，可输入范围：0 ~ 999999999</label><br>
        <label for="ebotime31">#31 EBO换药间隔时间（小时）：</label><input type="text" name="ebotime31" id="ebotime31" value="<?php echo $ebotime31 ?>"><label for="ebotime31"> 比如：2.5，可输入范围：0 ~ 999999999</label><br>
        <label for="ebotime38">#38 EBO换药间隔时间（小时）：</label><input type="text" name="ebotime38" id="ebotime38" value="<?php echo $ebotime38 ?>"><label for="ebotime38"> 比如：6，可输入范围：0 ~ 999999999</label><br>
        <label for="ebotimeRSA">RSA EBO换药间隔时间（小时）：</label><input type="text" name="ebotimeRSA" id="ebotimeRSA" value="<?php echo $ebotimeRSA ?>"><label for="ebotimeRSA"> 比如：6，可输入范围：0 ~ 999999999</label><br>
        <label for="ebotimeOther">其他 EBO换药间隔时间（小时）：</label><input type="text" name="ebotimeOther" id="ebotimeOther" value="<?php echo $ebotimeOther ?>"><label for="ebotimeOther"> 比如：6，可输入范围：0 ~ 999999999</label><br>
        <!-- <label for="Release">测试发布：</label><input type="text" name="Release" id="Release" value="<?php echo $Release ?>"><label for="Release">1为发行版，0为测试版</label><br> -->
        <h2>机台主机名和IP设置：</h2>
        <?php
        // 数组总个数
        $coun_mac = count($machines_arr);
        echo '<pre>';
        // var_dump($machines_arr);
        echo '</pre>';
        for ($i = 0; $i < $coun_mac; $i++) {
            if ($machines_arr[$i]['type'] != "测试" and $machines_arr[$i]['type'] != "RSA") {
                if ($machines_arr[$i]['id'] < 10 and strlen($machines_arr[$i]['id']) < 2) {
                    $machines_arr[$i]['id'] = "0" . $machines_arr[$i]['id'];
                }

        ?>
                <div class="leftRight">
                    <label for="">#<? echo $machines_arr[$i]['id'] ?> 主机名：</label>
                    <input type="text" name="macid[]" value="<? echo $machines_arr[$i]['id'] ?>" hidden>
                    <input type="text" name="mactype[]" value="<? echo $machines_arr[$i]['type'] ?>" hidden>
                    <input type="text" name="machost[]" value="<? echo $machines_arr[$i]['host'] ?>">
                    <label for="">IP：</label>
                    <input type="text" name="macip[]" value="<? echo $machines_arr[$i]['ip'] ?>">
                    <input type="text" name="macDataLog[]" value="<? echo $machines_arr[$i]['DataLog'] ?>" hidden>
                    <input type="text" name="macErrorLog[]" value="<? echo $machines_arr[$i]['ErrorLog'] ?>" hidden>
                    <input type="text" name="macEventLog[]" value="<? echo $machines_arr[$i]['EventLog'] ?>" hidden>
                    <input type="text" name="macStartStopLog[]" value="<? echo $machines_arr[$i]['StartStopLog'] ?>" hidden>
                    <input type="text" name="macdowntimelog[]" value="<? echo $machines_arr[$i]['downtimelog'] ?>" hidden>
                    <input type="text" name="macParameterLog/Machine[]" value="<? echo $machines_arr[$i]['ParameterLog/Machine'] ?>" hidden>
                    <input type="text" name="macParameterLog/Product[]" value="<? echo $machines_arr[$i]['ParameterLog/Product'] ?>" hidden>
                </div>
            <?php
            }
            if ($machines_arr[$i]['type'] == "RSA") {
                // var_dump($machines_arr[$i]['id']);
            ?>
                <div class="left">
                    <label for="">#<? echo $machines_arr[$i]['id'] ?> 主机名：</label>
                    <input type="text" name="macid[]" value="<? echo $machines_arr[$i]['id'] ?>" hidden>
                    <input type="text" name="mactype[]" value="<? echo $machines_arr[$i]['type'] ?>" hidden>
                    <input type="text" name="machost[]" value="<? echo $machines_arr[$i]['host'] ?>">
                    <label for="">IP：</label>
                    <input type="text" name="macip[]" value="<? echo $machines_arr[$i]['ip'] ?>">
                    <input type="text" name="macDataLog[]" value="<? echo $machines_arr[$i]['Rsa'] ?>" hidden>
                    <input type="text" name="macErrorLog[]" value="<? echo $machines_arr[$i]['Alarm'] ?>" hidden>
                    <!-- <input type="text" name="macEventLog[]" value="<? echo $machines_arr[$i]['EventLog'] ?>" hidden> -->
                    <!-- <input type="text" name="macStartStopLog[]" value="<? echo $machines_arr[$i]['StartStopLog'] ?>" hidden> -->
                    <input type="text" name="macdowntimelog[]" value="<? echo $machines_arr[$i]['Stopline'] ?>" hidden>
                    <!-- <input type="text" name="macParameterLog/Machine[]" value="<? echo $machines_arr[$i]['ParameterLog/Machine'] ?>" hidden> -->
                    <input type="text" name="macParameterLog/Product[]" value="<? echo $machines_arr[$i]['ParametricModifierLog'] ?>" hidden>
            <?php
            }
        }
            ?>
                </div>
                <div style="height:10px">&nbsp;</div>
    </form>
</body>

</html>