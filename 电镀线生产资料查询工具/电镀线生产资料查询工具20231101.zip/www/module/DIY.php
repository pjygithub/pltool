<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>自定义</title>
    <link rel="stylesheet" href="../layui/css/layui.css">
    <script src="../layui/layui.js"></script>
    <script src="../js/jquery.js"></script>
</head>
<style>
    .layui-form-item .layui-form-checkbox {
        margin-top: 3px;
    }

    .layui-form-checkbox {
        position: relative;
        height: 30px;
        line-height: 30px;
        margin-right: 20px;
        padding-right: 30px;
        cursor: pointer;
        font-size: 0;
        -webkit-transition: .1s linear;
        transition: .1s linear;
        box-sizing: border-box;
    }

    .layui-form-checkbox i {
        position: absolute;
        right: 0;
        top: 0;
        width: 30px;
        height: 28px;
        border: 1px solid #d2d2d2;
        border-left: none;
        border-radius: 0 2px 2px 0;
        color: #fff;
        font-size: 26px;
        text-align: center;
    }

    form {
        width: 100%;
        height: 90vh;
        overflow: auto;
    }

    .layui-input-block {
        position: relative;
        bottom: 0;
    }
</style>
<?php
// echo "<pre>";
// print_r($data[0]);
// print_r($_POST);
// print_r();
// 非数值，防止出错
$noValue = array(
    'Time',
    'L1 ED On/Off',
    'L1 ED2 On/Off',
    'L1 Cu Plating On/Off',
    'L1 Ag Strike On/Off',
    'L1 Ag Plating On/Off',
    'L1 BS(2) On/Off',
    'L1 M9 On/Off',
    'L1 Mode',
    'L2 ED On/Off',
    'L2 ED2 On/Off',
    'L2 Cu Plating On/Off',
    'L2 Ag Strike On/Off',
    'L2 Ag Plating On/Off',
    'L2 BS(2) On/Off',
    'L2 M9 On/Off',
    'Strand 1 Pre-Clean On/Off',
    'Strand 1 Post-dip IA On/Off',
    'Strand 1 Post-dip IB On/Off',
    'Strand 1 Status',
    'Strand 2 Pre-Clean On/Off',
    'Strand 2 Post-dip IA On/Off',
    'Strand 2 Post-dip IB On/Off',
    'Strand 2 Status',
    'L1',
    'L2',
    'Time',
    'L1 Mode',
    'L1 Tool ID',
    'L1 Electrode ID',
    'L1 ED On/Off',
    'L1 ED2 On/Off',
    'L1 Mode',
    'L1 Cu Plating On/Off',
    'L1 Ag Strike On/Off',
    'L1 Ag Plating On/Off',
    'L1 BS(2) On/Off',
    'L2 Mode',
    'L2 Tool ID',
    'L2 Electrode ID',
    'L2 ED On/Off',
    'L2 ED2 On/Off',
    'L2 Cu Plating On/Off',
    'L2 Ag Strike On/Off',
    'L2 Ag Plating On/Off',
    'L2 BS(2) On/Off',
    'Time',
    'L1 Mode',
    'L1 Electrode ID',
    'L1 Tool ID',
    'L1 EC On/Off',
    'L1 Ag Strike On/Off',
    'L1 BS On/Off',
    'L1 KоH On/Off',
    'L1 Cu On/Off',
    'L1 Ag On/Off',
    'L2 Mode',
    'L2 Electrode ID',
    'L2 Tool ID',
    'L2 EC On/Off',
    'L2 Ag Strike On/Off',
    'L2 BS On/Off',
    'L2 KоH On/Off',
    'L2 Cu On/Off',
    'L2 Ag On/Off',
    'L3 Mode',
    'L3 Electrode ID',
    'L3 Tool ID',
    'L3 EC On/Off',
    'L3 Ag Strike On/Off',
    'L3 BS On/Off',
    'L3 KоH On/Off',
    'L3 Cu On/Off',
    'L3 Ag On/Off',
    'EF1000(LowerTank) On/Off',
    'BS(Tank) On/Off',
    'Time',
    'L1 Tool ID',
    'L1 Electrode ID',
    'L1 ED(1) On/Off',
    'L1 ED(2) On/Off',
    'L1 ME2(1) On/Off',
    'L1 ME2(2) On/Off',
    'L1 ME2(1&2)LT On/Off',
    'L1 ME2(3) On/Off',
    'L1 ME2(4) On/Off',
    'L1 ME2(3&4)LT On/Off',
    'L1 KоH On/Off',
    'L2 Tool ID',
    'L2 Electrode ID',
    'L2 ED(1) On/Off',
    'L2 ED(2) On/Off',
    'L2 ME2(1) On/Off',
    'L2 ME2(2) On/Off',
    'L2 ME2(1&2)LT On/Off',
    'L2 ME2(3) On/Off',
    'L2 ME2(4) On/Off',
    'L2 ME2(3&4)LT On/Off',
    'L2 KоH On/Off',
    'L1 Tool ID',
    'L1 Electrode ID',
    'L1 Mode',
    'L1 ED On/Off',
    'L1 Pre-Acid Rinse On/Off',
    'L1 Ni Strike(1.1) On/Off',
    'L1 Ni Strike(1.2) On/Off',
    'L1 Ni Strike(2.1) On/Off',
    'L1 Ni Strike(2.2) On/Off',
    'L1 Pd Strike On/Off',
    'L1 Au Strike On/Off',
    'L2 Tool ID',
    'L2 Electrode ID',
    'L2 Mode L2 ED On/Off',
    'L2 Pre-Acid Rinse On/Off',
    'L2 Ni Strike(1.1) On/Off',
    'L2 Ni Strike(1.2) On/Off',
    'L2 Ni Strike(2.1) On/Off',
    'L2 Ni Strike(2.2) On/Off',
    'L2 Pd Strike On/Off',
    'L2 Au Strike On/Off',
    'LO Ni Strike(1)LT On/Off',
    'LO Ni Strike(2)LT On/Off'
);
$noValue = array_unique($noValue); // 删除重复
$noValue = array_values($noValue); // 重新编号
$noValue = array_filter($noValue);
$count = count($data[0]);
$maxStr = 0;
for ($i = 0; $i < $count; $i++) {
    if (in_array($title[$i], $noValue) == FALSE) {
        $teStrL = strlen(lang($data[0][$i]));
        // var_dump($teStrL);
        if ($maxStr <= $teStrL) {
            $maxStr = $teStrL;
        } else {
            $maxStr = $maxStr;
        }
    }
}
if ($_COOKIE['lang'] == "zh") {
    $maxStr = $maxStr / 2 - 3;
} else {
    $maxStr = $maxStr / 2;
}
?>
<style>
    .layui-input-block div {
        width: <?php echo $maxStr ?>rem;
    }

    .layui-input-block {
        margin-left: 5px;
    }
</style>

<body>
    <div><a href="javascript:showhide()" id="showhide" style="color:blue;font-size:13px;z-index:999">显示 筛选</a>（展开筛选项 → 筛选数据项 → 下滑拉点击“查询”按钮）</div>
    <form class="layui-form layui-anim-up" action="./DataLog.php" method="post" style="display:none" id="layui-form">
        <div class="layui-form-item">
            <!-- <label class="layui-form-label">选择数据：</label> -->
            <div class="layui-input-block">
                <?php
                $title = $data[0];
                if ($titleSort == 1) {
                    sort($title); // 选项排序
                }
                if ($titleSort == 2) {
                    rsort($title); // 选项排序
                }

                $count = count($data[0]);
                for ($i = 0; $i < $count; $i++) {
                    $name_ = str_replace('/', '___', $title[$i]);
                    if (in_array($title[$i], $noValue) == FALSE) {
                        // echo '<input type="checkbox" name="nick_cols[' . $name_ . ']" title="' . lang($title[$i]) . '">';
                        if ($_POST['nick_cols'][$name_] == 'on') {
                            echo '<input type="checkbox" name="nick_cols[' . $name_ . ']" lay-skin="tag" title="' . lang($title[$i]) . '" checked >';
                        } else {
                            echo '<input type="checkbox" name="nick_cols[' . $name_ . ']" lay-skin="tag" title="' . lang($title[$i]) . '">';
                        }
                    }
                }
                ?>
            </div>
        </div>
        <div class="layui-form-item">
            <div class="layui-input-block">
                <button class="layui-btn" lay-submit lay-filter="formDemo">查询</button>
                <button type="reset" class="layui-btn layui-btn-primary">重置</button>
            </div>
        </div>
    </form>

    <script>
        function showhide() {
            function $(id) {
                return document.getElementById(id);
            }
            var bom = document.defaultView.getComputedStyle($("layui-form"), null)
            var bomDis = bom.display;
            var box = document.querySelector('#layui-form');
            var box1 = document.querySelector('#showhide');
            if (bomDis == 'none') {
                box.style.display = "block";
                box1.innerHTML = "隐藏 筛选";
            } else {
                box.style.display = "none";
                box1.innerHTML = "显示 筛选";
            }
            // alert(qLL); //结果有值
        }
        var checkbokk = $('div.layui-input-block').children();
        console.log(checkbokk);
        // var maxlen = '0';
        // for (let j = 0; j < checkbokk.length; j++) {
        //     const ele = checkbokk[j];
        //     const lent = ele.title.length;
        //     if (lent > maxlen) {
        //         maxlen = lent;
        //     }
        //     console.log(ele);
        // }
        // for (let k = 0; k < checkbokk.length; k++) {
        //     const ele = checkbokk[k];
        //     // console.log(checkbokk);
        //     $(ele).css("color", "red");
        // }
        // $('.layui-form-checkbox>span').css('width', (maxlen - 5) + 'rem')
        //Demo
        layui.use('form', function() {
            var form = layui.form;
            //提交
            form.on('submit(formDemo)', function(data) {
                // layer.msg(JSON.stringify(data.field));
                layer.msg('正在查询。请稍后……');
                // return false;
            });
            form.on('reset(formDemo)', function(data) {
                // layer.msg(JSON.stringify(data.field));
                layer.msg('正在查询。请稍后……');
                // return false;
            });
        });
    </script>
</body>
<?php
$nick_col = array();
array_push($nick_col, 'Time', 'Date');
foreach ($_POST['nick_cols'] as $key => $value) {
    if ($value == 'on') {
        $name = str_replace('___', '/', $key);
        array_push($nick_col, $name);
    }
}
// echo '<pre>';
// print_r($nick_col);
?>

</html>