<!DOCTYPE html>
<html lang="zh_CN">

<head>
	<meta charset="UTF-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<script src="https://code.jquery.com/jquery-3.6.1.slim.js" integrity="sha256-tXm+sa1uzsbFnbXt8GJqsgi2Tw+m4BLGDof6eUPjbtk=" crossorigin="anonymous"></script>

	<title>机台状态查询</title>
</head>
<style>
	* {
		padding: 0px;
		margin: 0;
		font-size: 0.9rem;
	}

	.main {
		width: 99.5%;
		margin: 0 auto;
	}

	.top {
		font-size: 24px;
		text-align: center;
		margin-top: 5px;
		margin-bottom: 5px;
		font-weight: 800;
	}

	.F {
		width: 32%;
		/* background-color: bisque; */
		float: left;
		margin-left: 0.5%;
		margin-right: 0.5%;
	}

	table {
		border-collapse: collapse;
		/* Remove cell spacing */
		width: 100%;
	}

	tbody>tr>td {
		border: 1px solid #6d6d6d;
		padding: 1px;
		text-align: center;
		/* font-size: 0.9rem; */
		height: 1.2rem;
		padding-bottom: 0.2rem;
		padding-top: 0.2rem;
		/* width:12%; */
	}

	table>tbody>tr>th {
		width: 100%;
		font-size: 20px;
		font-weight: 600;
		text-align: center;
	}

	table>tbody>tr>td:nth-last-child(3) {
		text-align: center;
		/* padding-left: 0.8rem; */
	}

	._block {
		display: inline-block;
		width: 60px;
		height: 20px;
		margin-top: 5px;
		margin-left: 10px;
	}

	._block1 {
		display: inline-block;
		width: 30px;
		height: 15px;
		margin-top: 5px;
		margin-left: 10px;
	}

	.faster>td:nth-last-child(1) {
		background-color: #80ea80;
		font-weight: 600;
		color: green;
	}

	.faster>td:nth-last-child(2) {
		background-color: #80ea80;
		font-weight: 600;
		color: green;
	}

	.slow>td:nth-last-child(1) {
		background-color: #9090f7;
		font-weight: 600;
		color: white;
	}

	.slow>td:nth-last-child(2) {
		background-color: #9090f7;
		font-weight: 600;
		color: white;
	}

	.stop>td:nth-last-child(1) {
		background-color: #f78282;
		font-weight: 600;
		color: red;
	}

	.stop>td:nth-last-child(2) {
		background-color: #f78282;
		font-weight: 600;
		color: red;
	}

	.offline>td:nth-last-child(1) {
		background-color: #ffffab;
		font-weight: 600;
		color: black;
	}

	.offline>td:nth-last-child(2) {
		background-color: #ffffab;
		font-weight: 600;
		color: black;
	}

	.pl209 {
		background-color: #ececec;
	}

	.sr {
		background-color: #c0c0c0;
	}

	.me2 {
		background-color: #c5c9f3;
	}

	.ppf {
		background-color: #d4f3c5;
	}

	.bot {
		background-color: #f3c8f0;
	}

	.title {
		background-color: #999999;
		color: white;
	}

	.timeless {
		width: 50%;
		position: relative;
		left: 1%;
		top: 0%;
		font-size: 20px;
		font-weight: 700;
	}

	.timeless>span {
		font-size: 20px;
		font-weight: 700;
	}

	.fenge {
		border-bottom: 3px solid #6d6d6d;
	}
</style>

<body>
	<div class="main">
		<!-- <div class="top">机台状态查询</div> -->
		<div class="F">
			<table>
				<tbody>
					<tr>
						<th colspan="4">12/3F</th>
					</tr>
					<tr class="title">
						<td>机台</td>
						<td>产品档案</td>
						<td>生产速度</td>
						<td>目标速度</td>
					</tr>
					<tr id="27A" class="me2">
						<td rowspan="2">27</td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="27B" class="me2">
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="28A" class="pl209">
						<td rowspan="2">28</td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="28B" class="pl209">
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="29A" class="pl209">
						<td rowspan="2">29</td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="29B" class="pl209">
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="30A" class="me2">
						<td rowspan="2">30</td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="30B" class="me2">
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="31A" class="sr">
						<td rowspan="3">31</td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="31B" class="sr">
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="31C" class="sr">
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="32A" class="me2">
						<td rowspan="2">32</td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="32B" class="me2">
						<td></td>
						<td></td>
						<td></td>
					</tr>

					<tr id="35A" class="me2">
						<td rowspan="2">35</td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="35B" class="me2">
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<th colspan="4">6/3F</th>
					</tr>
					<tr id="34A" class="sr">
						<td rowspan="3">34</td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="34B" class="sr">
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="34C" class="sr">
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td colspan="4" style="text-align: left; border: 1px solid #fff">
							<br />
							<span class="_block1" style="background-color: #ececec">&nbsp;</span>
							快机<span class="_block1" style="background-color: #c0c0c0">&nbsp;</span>
							慢机<span class="_block1" style="background-color: #c5c9f3">&nbsp;</span>
							ME2<span class="_block1" style="background-color: #d4f3c5">&nbsp;</span>
							钯机<span class="_block1" style="background-color: #f3c8f0">&nbsp;</span>
							棕色氧化<br />
							<span class="_block" style="background-color: #80ea80">&nbsp;</span>
							生产速度 ≥ 目标速度 && 速度(m/min)<br />
							<span class="_block" style="background-color: #9090f7">&nbsp;</span>
							生产速度＜目标速度 && 速度(m/min)<br />
							<span class="_block" style="background-color: #f78282">&nbsp;</span>
							停机 && 停机时间<br />
							<span class="_block" style="background-color: #ffffab">&nbsp;</span>
							断网/无服务
							<br />
							<div class="timeless">
								<br />页面刷新倒计时：<span>0 s</span>
							</div>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
		<div class="F">
			<table>
				<tbody>
					<tr>
						<th colspan="4">13/3F</th>
					</tr>
					<tr class="title">
						<td>机台</td>
						<td>产品档案</td>
						<td>生产速度</td>
						<td>目标速度</td>
					</tr>
					<tr id="01A" class="pl209">
						<td rowspan="2">01</td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="01B" class="pl209">
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="02A" class="pl209">
						<td rowspan="2">02</td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="02B" class="pl209">
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="03A" class="pl209">
						<td rowspan="2">03</td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="03B" class="pl209">
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="04A" class="pl209">
						<td rowspan="2">04</td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="04B" class="pl209">
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="05A" class="pl209">
						<td rowspan="2">05</td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="05B" class="pl209">
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="06A" class="pl209">
						<td rowspan="2">06</td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="06B" class="pl209">
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="07A" class="pl209">
						<td rowspan="2">07</td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="07B" class="pl209 fenge">
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="08A" class="pl209">
						<td rowspan="2">08</td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="08B" class="pl209">
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="09A" class="pl209">
						<td rowspan="2">09</td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="09B" class="pl209">
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="10A" class="sr">
						<td rowspan="3">10</td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="10B" class="sr">
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="10C" class="sr">
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="11A" class="pl209">
						<td rowspan="2">11</td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="11B" class="pl209">
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="12A" class="sr">
						<td rowspan="4">12</td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="12B" class="sr">
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="12C" class="sr">
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="12D" class="sr">
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="13A" class="pl209">
						<td rowspan="2">13</td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="13B" class="pl209">
						<td></td>
						<td></td>
						<td></td>
					</tr>

					<tr id="14A" class="pl209">
						<td rowspan="2">14</td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="14B" class="pl209">
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<td colspan="4" style="border: 1px solid #fff"></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div class="F">
			<table>
				<tbody>
					<tr>
						<th colspan="4">14/3F</th>
					</tr>
					<tr class="title">
						<td>机台</td>
						<td>产品档案</td>
						<td>生产速度</td>
						<td>目标速度</td>
					</tr>

					<tr id="15A" class="ppf">
						<td rowspan="2">15</td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="15B" class="ppf">
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="18A" class="ppf">
						<td rowspan="2">18</td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="18B" class="ppf fenge">
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="19A" class="pl209">
						<td rowspan="2">19</td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="19B" class="pl209">
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="20A" class="pl209">
						<td rowspan="2">20</td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="20B" class="pl209">
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="21A" class="pl209">
						<td rowspan="2">21</td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="21B" class="pl209">
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="22A" class="pl209">
						<td rowspan="2">22</td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="22B" class="pl209 fenge">
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="23A" class="bot">
						<td rowspan="2">23</td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="23B" class="bot">
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="24A" class="bot">
						<td rowspan="2">24</td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="24B" class="bot">
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="25A" class="bot">
						<td rowspan="2">25</td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="25B" class="bot fenge">
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="26A" class="ppf">
						<td rowspan="2">26</td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="26B" class="ppf">
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="36A" class="ppf">
						<td rowspan="2">36</td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="36B" class="ppf">
						<td></td>
						<td></td>
						<td></td>
					</tr>

					<tr id="37A" class="ppf">
						<td rowspan="2">37</td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="37B" class="ppf">
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr>
						<th colspan="4">6/1F</th>
					</tr>
					<tr id="38A" class="pl209">
						<td rowspan="2">38</td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="38B" class="pl209">
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="RSAA" class="">
						<td rowspan="2">RSA</td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
					<tr id="RSAB" class="">
						<td></td>
						<td></td>
						<td></td>
					</tr>
				</tbody>
			</table>
		</div>
		<br />
	</div>

	<script>
		function rand(start, end) {
			var x = start;
			var y = end; //随意调数字，现在是90-100以内的随机数
			var rand = Math.random() * (x - y + 1) + y; //parseInt
			return rand;
		}
		var machineL = [
			'01A',
			'01B',
			'02A',
			'02B',
			'03A',
			'03B',
			'04A',
			'04B',
			'05A',
			'05B',
			'06A',
			'06B',
			'07A',
			'07B',
			'08A',
			'08B',
			'09A',
			'09B',
			'10A',
			'10B',
			'10C',
			'11A',
			'11B',
			'12A',
			'12B',
			'12C',
			'12D',
			'13A',
			'13B',
			'14A',
			'14B',
			'15A',
			'15B',
			'16A',
			'16B',
			'17A',
			'17B',
			'18A',
			'18B',
			'19A',
			'19B',
			'20A',
			'20B',
			'21A',
			'21B',
			'22A',
			'22B',
			'23A',
			'23B',
			'24A',
			'24B',
			'25A',
			'25B',
			'26A',
			'26B',
			'27A',
			'27B',
			'28A',
			'28B',
			'29A',
			'29B',
			'30A',
			'30B',
			'31A',
			'31B',
			'31C',
			'32A',
			'32B',
			'33A',
			'33B',
			'34A',
			'34B',
			'34C',
			'35A',
			'35B',
			'36A',
			'36B',
			'37A',
			'37B',
			'38A',
			'38B',
			'RSAA',
			'RSAB',
		];
		var type = ['X', 'M', 'T', 'D', 'F', 'W', 'A', 'S'];
		var line = ['A', 'B', 'C', 'D'];
		var NO_ = [
			'A',
			'B',
			'C',
			'D',
			'E',
			'F',
			'G',
			'H',
			'I',
			'J',
			'K',
			'L',
			'M',
			'N',
			'O',
			'P',
			'Q',
			'R',
			'S',
			'T',
			'U',
			'V',
			'W',
			'X',
			'W',
			'Z',
			0,
			1,
			2,
			3,
			4,
			5,
			6,
			7,
			8,
			9,
		];
		var number = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0];
		var zimu = [
			'A',
			'B',
			'C',
			'D',
			'E',
			'F',
			'G',
			'H',
			'I',
			'J',
			'K',
			'L',
			'M',
			'N',
			'O',
			'P',
			'Q',
			'R',
			'S',
			'T',
			'U',
			'V',
			'W',
			'X',
			'W',
			'Z',
		];
		var status_data = [];
		for (let index = 0; index < machineL.length; index++) {
			let re = {};
			const ele = machineL[index];
			const Speed = rand(0, 0).toFixed(2);
			// Speed = 0;
			const targetSpeed = rand(0, 0).toFixed(1);
			re.id = ele;
			re.Speed = Speed;
			re.targetSpeed = targetSpeed;
			const T = type[parseInt(rand(0, type.length - 1))];
			const L = line[parseInt(rand(0, 3))];
			const a = number[parseInt(rand(0, number.length - 1))];
			const b = number[parseInt(rand(0, number.length - 1))];
			const c = zimu[parseInt(rand(0, zimu.length - 1))];
			const d = zimu[parseInt(rand(0, zimu.length - 1))];
			const e = zimu[parseInt(rand(0, zimu.length - 1))];
			const f = number[parseInt(rand(0, number.length - 1))];
			const g = number[parseInt(rand(0, number.length - 1))];
			const h = number[parseInt(rand(0, number.length - 1))];
			const i = number[parseInt(rand(0, number.length - 1))];
			const j = number[parseInt(rand(0, number.length - 1))];
			const k = number[parseInt(rand(0, number.length - 1))];
			const l = number[parseInt(rand(0, number.length - 1))];
			const m = number[parseInt(rand(0, number.length - 1))];
			const n = number[parseInt(rand(0, number.length - 1))];
			const o = NO_[parseInt(rand(0, NO_.length - 1))];
			const p = NO_[parseInt(rand(0, NO_.length - 1))];
			const q = number[parseInt(rand(0, number.length - 1))];
			const r = number[parseInt(rand(0, number.length - 1))];
			const s = number[parseInt(rand(0, number.length - 1))];
			const t = number[parseInt(rand(0, number.length - 1))];
			const u = number[parseInt(rand(0, number.length - 1))];
			const n1 = number[parseInt(rand(0, number.length - 1))];
			const n2 = number[parseInt(rand(0, number.length - 1))];
			const n3 = number[parseInt(rand(0, number.length - 1))];
			const n4 = number[parseInt(rand(0, number.length - 1))];
			const n5 = number[parseInt(rand(0, number.length - 1))];
			const n6 = number[parseInt(rand(0, number.length - 1))];
			// XA08 - SOM080986001K(AMPMR00676);
			NOO_ =
				T +
				L +
				a +
				b +
				'-' +
				n1 +
				n2 +
				n3 +
				n4 +
				n5 +
				n6 +
				c +
				d +
				e +
				f +
				g +
				h +
				i +
				j +
				k +
				l +
				m +
				n +
				o +
				'(AMPM' +
				p +
				q +
				r +
				s +
				t +
				u +
				')';
			re.ProductNO = NOO_;
			// console.log(re);
			status_data.push(re);
		}
		// console.log(status_data);

		for (let i = 0; i < status_data.length; i++) {
			const ele = status_data[i];
			//操作样式
			if (ele.Speed > ele.targetSpeed || ele.Speed == ele.targetSpeed) {
				$('#' + ele.id).addClass('faster');
			}
			if (ele.Speed < ele.targetSpeed) {
				$('#' + ele.id).addClass('slow');
			}
			if (ele.Speed == 0) {
				$('#' + ele.id).addClass('stop');
			}
			if (ele.Speed == 0 && ele.targetSpeed == 0) {
				$('#' + ele.id).addClass('offline');
			}
			if (
				$('#' + ele.id)
				.children()
				.eq(-3)
				.html() != '' &&
				$('#' + ele.id)
				.children()
				.html() != '' &&
				$('#' + ele.id)
				.children()
				.eq(-1)
				.html() != ''
			) {} else {
				$('#' + ele.id)
					.children()
					.eq(-3)
					.append(ele.ProductNO);
				$('#' + ele.id)
					.children()
					.eq(-2)
					.append(ele.Speed);
				$('#' + ele.id)
					.children()
					.eq(-1)
					.append(ele.targetSpeed);
			}
			// console.log(ele);
		}
		var timeless = 30;
		ttt = timeless;
		setInterval(function() {
			$('.timeless')
				.children()
				.html(ttt + ' s');
			ttt = ttt - 1;
			if (ttt == 0 || ttt < 0) {
				window.location.reload();
				$('.timeless').children().html('1 s');
			}
		}, 1000);
	</script>
</body>

</html>