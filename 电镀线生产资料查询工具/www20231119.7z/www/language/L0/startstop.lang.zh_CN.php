<?php
$zh_lang_startstop = array(
    "Date" => "日期",
    "date" => "日期",
    "time" => "时间",
    "Time" => "时间",
    "Event" => "事件",
    "event" => "事件",
);
