<?php
$zh_lang_errorlog = array();
