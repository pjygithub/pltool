<?
$user = 'P02PUBILC';
$password = 'P02147258369';
   
//设定域信息
$domain = 'aam-intl.com'; //设定域名
$basedn = 'dc=aam-intl,dc=com'; //如果域名为“b.a.com”,则此处为“dc=b,dc=a,dc=com”
   
$ad = ldap_connect ( "ldap://{$domain}" ) or die ( '<h1>Could not connect to LDAP server.</h1>' );
ldap_set_option ( $ad, LDAP_OPT_PROTOCOL_VERSION, 3 );
ldap_set_option ( $ad, LDAP_OPT_REFERRALS, 0 );
$bd = @ldap_bind ( $ad, "{$user}@{$domain}", $password ) or die ( '<h1>Authorization failed! <br> Please check your username or password!</h1>' );
if($bd){
        //echo "OK";
        $result = ldap_search($ad,"OU=$str,dc=explame,dc=com","(|(CN=$name)(UserPrincipalName=$name))") or die ("Error in query");    //根据条件搜索，我这边搜索的是要查看ad域中是否有改字段。这是一个相当于or的搜索
        $info = ldap_get_entries($ad, $result); //获取认证用户的信息
        echo "您的相关信息：".$info[0]["distinguishedname"][0];
    } else {
        echo "Username or password error!";
    }
    ldap_close($ad);//关闭
echo "Welcome ".$user;
?>