<?php
// 设置请求头和时区
ini_set('user_agent', 'Linux W-Get Monitor2 index.php set');
ini_set('date.timezone', 'Asia/Shanghai');
