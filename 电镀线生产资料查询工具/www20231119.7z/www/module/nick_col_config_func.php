<pre>
<?
var_dump($_POST);
?>

</pre>