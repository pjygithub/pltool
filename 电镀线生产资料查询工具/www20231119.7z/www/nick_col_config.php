<?php
// echo "设置<br>";
include(dirname(__DIR__) . '/www/module/common_config.php');
// include(dirname(__DIR__) . '/www/machines.config.json');
$machines_str = file_get_contents(dirname(__DIR__) . '/www/machines.config.json');
$machines_arr = json_decode($machines_str, true);
?>
<!DOCTYPE html>
<html lang="zh_cn">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>表头设置</title>
    <script src="./layui/layui.js"></script>
    <link rel="stylesheet" href="./layui/css/layui.css">
    <script src="js/jquery.js"></script>
</head>
<style>
    * {
        font-size: 1rem;
    }

    input {
        padding-left: 10px;
    }

    input[type=text] {
        /* width: 26rem; */
        /* width: 30%; */
        height: 2rem;
        border: 0px;
        border-bottom: 1px solid #333;
        margin-left: 10px;
        margin-right: 10px;
    }

    input[type=number] {
        /* width: 26rem; */
        /* width: 30%; */
        height: 2rem;
        border: 0px;
        border-bottom: 1px solid #333;
    }

    .leftRight {
        width: 49.5%;
        /* position: absolute; */
        float: left;
    }

    .layui-btn1 {
        position: fixed;
        height: 36px;
        line-height: 36px;
        border: 1px solid transparent;
        padding: 0 18px;
        background-color: #009688;
        color: #fff;
        white-space: nowrap;
        text-align: center;
        font-size: 14px;
        border-radius: 20px;
        cursor: pointer;
        outline: 0;
        -webkit-appearance: none;
        transition: all .3s;
        -webkit-transition: all .3s;
        box-sizing: border-box;
        top: 0;
        left: 0;
    }

    table>tbody>tr>td {
        /* border: 1px solid red; */
        text-align: center;
    }
</style>
<?php
// 关闭报错
include(dirname(__DIR__) . '/www/module/close_debuger.php');
// 载入公共配置
include_once(dirname(__DIR__) . '/www/module/common_config.php');
// 按需加载
if (isset($_COOKIE['lang']) and $_COOKIE['lang'] == 'en') {
    include(dirname(__DIR__) . '\www\language\lang.en.php'); //英文语言文件
} else {
    include(dirname(__DIR__) . '\www\language\lang.zh_CN.php'); //中文语言文件
}
// 机台号预处理
include(dirname(__DIR__) . '/www/module/using_machine.php');
// 输出机台选择信息
// echo '<pre>';
// print_r($machines_arr[$index]);
// 判断机台是否存在某个文件夹
if ($machines_arr[$index]['type'] == 'RSA') {
    $dirname = 'Rsa';
} else {
    $dirname = 'DataLog';
}
include(dirname(__DIR__) . '/www/module/isexistDIR.php');
// 列出选定的日期、月份、年份
include(dirname(__DIR__) . '/www/module/Dates.php');
$Dates = Dates('Y-m-d');
// echo '<pre>';
// print_r($Dates);

// 打开并返回数据流 $data
$format_normal = '_data';
$format_rsa = 'Rsa_';
include(dirname(__DIR__) . '/www/module/get_data_DataLog_only.php');
$data = get_data_lines($Dates, $dirname, $format_normal, $format_rsa);
// echo '<pre>';
// print_r($data);
$db_file = dirname(__DIR__) . "/www/SQLite/DB_PLtool.sqlite3";
$db_handle = new SQLite3($db_file);
// 检测连接是否成功
if (!$db_handle) {
    die("数据库连接失败: " . $db_handle->lastErrorMsg());
}
// 执行SQL语句
$results = $db_handle->query('SELECT * FROM `tb_type_nick_col`');
// 检测SQL执行是否成功
if (!$results) {
    die("SQL执行错误: " . $db_handle->lastErrorMsg());
}
// 遍历结果集
$arr_type = array();
while ($row = $results->fetchArray()) {
    $r = array("id" => $row["id"], "type" => $row['type']);
    array_push($arr_type, $r);
}
// echo '<pre>';
// var_dump($arr_type);
// 关闭数据库连接
$db_handle->close();
?>

<body>
    <form action="./module/nick_col_config_func.php" method="post">
        <input type="submit" value="保存设置" class="layui-btn1" style="z-index:999">
        <h2 style="margin-top:2rem;">运行图表显示项设置</h2>

        <table class="layui-table" lay-even>
            <colgroup>
                <col width="150">
                <col width="150">
                <col>
            </colgroup>
            <thead>
                <tr>
                    <th>序号</th>
                    <th>表头(源)</th>
                    <th>表头(汉)</th>
                    <th>类型选择</th>
                    <th>线0显示</th>
                    <th>线1显示</th>
                    <th>线2显示</th>
                    <th>线3显示</th>
                    <th>线4显示</th>
                    <th>默认显示</th>
                    <th>重要参数显示</th>
                    <th>是否数值</th>
                </tr>
            </thead>
            <tbody id="tb_data">
                <?php
                $count_data = count($data[0]);
                for ($i = 0; $i < $count_data; $i++) {
                    $ch_nick_col = lang($data[0][$i]);
                    echo '<tr>';
                    echo '<td>' . ($i + 1) . '</td>';
                    echo '<td>' . $data[0][$i] . '</td>';
                    echo '<td>' . lang($data[0][$i]) . '</td>';
                    echo '<td><div class="layui-col-md6">
                <select lay-search="" name="nick_col_type[]">
                  <option value="">请选择类型</option>';
                    for ($j = 0; $j < count($arr_type); $j++) {
                        echo '<option value="' . $arr_type[$j]['id'] . '">' . lang($arr_type[$j]['type']) . '</option>';
                    }
                    echo '</select></div></td>';
                    echo '<td><div class="layui-form">
              <input type="checkbox" name="nick_col_L0[]" lay-text="线0"> 
            </div></td>';
                    echo '<td><div class="layui-form">
              <input type="checkbox" name="nick_col_L1[]" lay-text="线1"> 
            </div></td>';
                    echo '<td><div class="layui-form">
              <input type="checkbox" name="nick_col_L2[]" lay-text="线2"> 
            </div></td>';
                    echo '<td><div class="layui-form">
              <input type="checkbox" name="nick_col_L3[]" lay-text="线3"> 
            </div></td>';
                    echo '<td><div class="layui-form">
              <input type="checkbox" name="nick_col_L4[]" lay-text="线4"> 
            </div></td>';
                    echo '<td><div class="layui-form">
              <input type="checkbox" name="nick_col_Def[]" lay-text="默认" > 
            </div></td>';
                    echo '<td><div class="layui-form">
              <input type="checkbox" name="nick_col_main[]" lay-text="重要参数"> 
            </div></td>';
                    echo '<td><div class="layui-form">
              <input type="checkbox" name="nick_col_isNum[]" lay-text="是否数值" checked> 
            </div></td>';
                    echo '</tr>';
                }
                ?>
            </tbody>
        </table>
    </form>
    <div style="height:10px">&nbsp;</div>

    <?php

    ?>
</body>

</html>