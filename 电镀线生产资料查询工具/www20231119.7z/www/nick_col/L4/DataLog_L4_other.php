<?
$DataLog_L4_other = array(
    "Time",
    "AgStrikePHMeter",
    "HI Ni ASD",
    "L0 Pd(PH)",
    "L0_PH",
    "L4 AgStrike",
    "L4 LF Length Counter",
    "M4AgStrike(1)",
    "M4DropCount",
    "M5AgSpot",
    "M5DropCount",
    "OBS Dummy ApHr Read",
    "Pd Strike Level",
    "SBS Dummy ApHr Read",
);
$nick_col = $DataLog_L4_other;
