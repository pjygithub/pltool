<?
$DataLog_L4_Conductivity = array(
    "Time",
    "L4 Conductivity",
    "L4 Conductivity",
    "M10 Conduct",
    "L4 Cond",
    "L4 Anti-EBO Conductivity",
    "L4 Anti-EBO Conductivity",
    "UltrasonicWaterConductivity",
    "Conductivity",
    "L0 Conductivity",
    "L0_Conductivity_RDI",
    "L4 Anti-EBO Conductivity",
    "L4 Cond",
    "L4 Conductivity",
    "M10 Conduct",
    "M10 Conduct",
    "M2 Conduct 1",
    "M2 Conduct 2",
    "UltrasonicWaterConductivity",

);
$nick_col = $DataLog_L4_Conductivity;
