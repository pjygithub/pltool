<?
$DataLog_L3_Pressure = array(
    "Time", "CompressedAirPressureMeter",
    "CoolingWaterPressureMeter",
    "DIPressureMeter",
    "L0 Ni Strike(1)(In)",
    "L0 Ni Strike(1)(Out)",
    "L0 Ni Strike(2)(In)",
    "L0 Ni Strike(2)(Out)",
    "L0CWPressure",
    "L0DIPressure",
    "L3 Air",
    "L3 Gas-Pressure",
    "L3 Air",
    "L3 Gas-Pressure",
    "M10 AirBlow Inlet",
    "ROPressureMeter",
);
$nick_col = $DataLog_L3_Pressure;
