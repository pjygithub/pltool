<?
$DataLog_L3_FlowRate = array(
    "Time",
    "Au Strike Level",
    "CompressedAirFlowMeter",
    "DI FlowMeter",
    "DI FlowMeter",
    "DIFlowMeter",
    "L0 Ni Strike(1)(In)",
    "L0 Ni Strike(1)(Out)",
    "L0 Ni Strike(2)(In)",
    "L0 Ni Strike(2)(Out)",
    "L0CWFlowRate",
    "L0DIFlowRate",
    "L0M10DI(1)Flow",
    "L3 DI",
    "L3 RO",
    "L3 DI",
    "L3 RO",
    "Ni Strike(1)(In) FlowMeter",
    "Ni Strike(2)(In) FlowMeter",
    "Ni Strike(1)(In) FlowMeter",
    "Ni Strike(2)(In) FlowMeter",
    "RO FlowMeter",
    "RO FlowMeter",
    "ROFlowMeter",

);
$nick_col = $DataLog_L3_FlowRate;
