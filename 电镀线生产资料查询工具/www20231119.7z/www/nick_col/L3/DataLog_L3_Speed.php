<?php
$DataLog_L3_Speed = array(
    "Time",
    "L3 Offload Speed",
    "L3 Plating Time",
    "L3 Run Speed",
    "L3 Running Speed",
    "L3 Speed Read",
    "L3 Speed Set",
    "L3 SpeedMeter",
    "L3 Standard Speed",
    "L3 Target  Speed",
    "L3 Target Speed",
    "L3 Plating Time",
    "L3 Run Speed",
    "L3SpeedRead",
    "L3SpeedSet",
    "Strand 3 Running Speed",
);
$nick_col = $DataLog_L3_Speed;
