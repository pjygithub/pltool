<?
$DataLog_L3_other = array(
    "Time",
    "AgStrikePHMeter",
    "EC L3 ApHr Read",
    "HI Ni ASD",
    "L0 Pd(PH)",
    "L0_PH",
    "L3 AgStrike",
    "L3 LF Length Counter",
    "L3 LF Length Counter",
    "M4AgStrike(1)",
    "M4DropCount",
    "M5AgSpot",
    "M5DropCount",
    "OBS Dummy ApHr Read",
    "OBS L3 ApHr Read",
    "Pd Strike Level",
    "SBS Dummy ApHr Read",
    "SBS L3 ApHr Read",
    "SBS2 L3 ApHr Read",
);
$nick_col = $DataLog_L3_other;
