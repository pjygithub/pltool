<?
$DataLog_L3_Conductivity = array(
    "Time",
    "L3 Conductivity",
    "L2 Conductivity",
    "M10 Conduct",
    "L3 Cond",
    "L3 Anti-EBO Conductivity",
    "L3 Anti-EBO Conductivity",
    "UltrasonicWaterConductivity",
    "Conductivity",
    "L0 Conductivity",
    "L0_Conductivity_RDI",
    "L3 Anti-EBO Conductivity",
    "L3 Cond",
    "L3 Conductivity",
    "L3 Cond",
    "M10 Conduct",
    "M10 Conduct",
    "M2 Conduct 1",
    "M2 Conduct 2",
    "UltrasonicWaterConductivity", "L2/3 Cond",
    "L2/3 Conductivity",


);
$nick_col = $DataLog_L3_Conductivity;
