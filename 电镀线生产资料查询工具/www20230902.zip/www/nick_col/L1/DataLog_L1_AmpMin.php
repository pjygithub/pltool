<?
$DataLog_L1_AmpMin = array(
    "Time",
    "M3AmpMin",
    "M4AmpMin",
    "M5AmpMin",
    "M3 AmpMin",
    "M4 AmpMin",
    "M5 AmpMin",
    "L1 M1AmpMin",
    "L1 M1 AmpMin",
    "L1 ECAmpMin",
    "L1 EC AmpMin",
    "L1 CuStrikeAmpmin",
    "L1CuStrikeAmpmin",
    "L1 M5AmpMin",
    "L1 M5 AmpMin",
    "L1Ag1Ampmin",
    "L1Ag2Ampmin",
    "L1 M7AmpMin",
    "L1 BS AmpMin",
    "Ag Strike AmpMin",
    "Ag Strike DropCount",
    "Au Amp*Min",
    "Auto Dose Counter",
    "Auto Dose Counter",

);
$nick_col = $DataLog_L1_AmpMin;
