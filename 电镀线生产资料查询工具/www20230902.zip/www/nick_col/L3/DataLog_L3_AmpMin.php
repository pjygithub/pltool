<?
$DataLog_L3_AmpMin = array(
    "Time",
    "M3AmpMin",
    "M4AmpMin",
    "M5AmpMin",
    "L3 BS AmpMin",
    "L3 EC AmpMin",
    "M3AmpMin",
    "M4AmpMin",
    "M5AmpMin",
    "L3 LF Length Counter",
);
$nick_col = $DataLog_L3_AmpMin;
