<?
$DataLog_L4_other = array("Time",  "Oxi. Treat. I coller", "Oxi. Treat. II coller", "Oxi. Treat. III coller", "Onload 1 LF count", "Offload 1 LF count", "Onload 2 LF count", "Offload 2 LF count", "M2 Conduct 1", "M2 Conduct 2", "Auto Dose Counter", "L1 Length", "L2 Length", "L0 Ni Strike(1)(In)", "L0 Ni Strike(1)(Out)", "L0 Ni Strike(2)(In)", "L0 Ni Strike(2)(Out)", "M4DropCount", "M5DropCount", "Ag_1_PHMeter", "Ag_1_S_G_Meter", "Ag_2_PHMeter", "Ag_2_S_G_Meter", "AgStrikePHMeter", "L1StrippingAutoDose", "L2AgStrikePh", "L2StrippingAutoDose");
$nick_col = $DataLog_L4_other;
