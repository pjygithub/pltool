<?
$DataLog_L3_Conductivity = array(
    "Time",
    "L3 Conductivity",
    "L2 Conductivity",
    "M10 Conduct",
    "L3 Cond",
    "L3 Anti-EBO Conductivity",
    "L3 Anti-EBO Conductivity",
    "UltrasonicWaterConductivity"
);
$nick_col = $DataLog_L3_Conductivity;