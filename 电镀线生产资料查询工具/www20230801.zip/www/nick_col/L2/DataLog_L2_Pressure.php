<?
$DataLog_L2_Pressure = array("Time", "L0CWPressure", "L1CWPressure", "L2CWPressure", "L1ROPressure", "L2ROPressure", "L1AIRPressure", "L2AIRPressure", "L0DIPressure", "L1DIPressure", "L2DIPressure", "L1OIL-FREEPressure", "L2OIL-FREEPressure", "L1 Air", "L2 Air", "L3 Air", "L1 Gas-Pressure", "L2 Gas-Pressure", "L3 Gas-Pressure", "ROPressureMeter", "DIPressureMeter", "CoolingWaterPressureMeter", "CompressedAirPressureMeter");
$nick_col = $DataLog_L2_Pressure;
