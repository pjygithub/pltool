<?
$DataLog_L2_AmpMin = array(
    "Time",
    "M3AmpMin",
    "M4AmpMin",
    "M5AmpMin",
    "L2 M5AmpMin",
    "L2 M7AmpMin",
    "L2 M1AmpMin",
    "L2 BS AmpMin",
    "L2 EC AmpMin",
    "M3AmpMin",
    "M4AmpMin",
    "M5AmpMin",
    "L2 LF Length Counter",
    "L2Ag1Ampmin",
    "L2Ag2Ampmin",
    "L2CuStrikeAmpmin"
);
$nick_col = $DataLog_L2_AmpMin;
