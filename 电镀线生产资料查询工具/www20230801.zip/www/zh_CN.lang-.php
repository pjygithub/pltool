<?php
function lang($str)
{
    $_lang = array(
        // 公共部分
        
    );
    // array_search($str, $_arr);
    if (isset($_lang[$str]) and $_lang[$str] != "") {
        return $_lang[$str];
    } else {
        return $str;
    }
}

// echo lang("L1 Conductivity");
