<?
$StartStopLog_lang_zh_CN = array(
    "Date" => "日期",
    "date" => "日期",
    "time" => "时间",
    "Time" => "时间",
    "Event" => "事件",
    "event" => "事件"
);
$_lang = $StartStopLog_lang_zh_CN;
