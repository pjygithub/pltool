<?
$DataLog_L4_Speed = array(
    "Time",
    "L4 Target Speed",
    "L4 Target  Speed",
    "L4 Running Speed",
    "L4 Standard Speed",
    "L4 Offload Speed",
    "Strand 4 Running Speed",
    "L4 Plating Time",
    "L4 Run Speed",
    "L4 Running Speed",
    "L4 SpeedMeter",
    "L4 Target Speed",
    "L2 Running Speed",
    "L2 SpeedMeter",
    "L4 Running Speed",
    "L4 SpeedMeter",
    "L4 Standard Speed",
    "L4 Target  Speed",
    "L4SpeedRead",
    "L4SpeedSet"
);
$nick_col = $DataLog_L4_Speed;
