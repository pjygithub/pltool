<?
$DataLog_L4_AmpMin = array(
    "Time",
    "M3AmpMin",
    "M4AmpMin",
    "M5AmpMin",
    "L4 BS AmpMin",
    "L4 EC AmpMin",
    "M3AmpMin",
    "M4AmpMin",
    "M5AmpMin",
    "L4 LF Length Counter",
);
$nick_col = $DataLog_L4_AmpMin;
