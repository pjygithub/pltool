<?
$DataLog_L1_Speed = array(
    "Time",
    "L1 Target Speed",
    "L1 Target  Speed",
    "L1 Running Speed",
    "L1 Standard Speed",
    "L1 Offload Speed",
    "Strand 1 Running Speed",
    "L1 Plating Time",
    "L1 Run Speed",
    "L1 Running Speed",
    "L1 SpeedMeter",
    "L1 Target Speed",
    "L1 Running Speed",
    "L1 SpeedMeter",
    "L1 Standard Speed",
    "L1 Target  Speed",
    "L1SpeedRead",
    "L1SpeedSet"
);
$nick_col = $DataLog_L1_Speed;