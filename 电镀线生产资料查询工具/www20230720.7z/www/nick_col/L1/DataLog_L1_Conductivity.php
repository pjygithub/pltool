<?
$DataLog_L1_Conductivity = array(
    "Time",
    "L1 Conductivity",
    "L1 Conductivity",
    "L1/2 Conductivity",
    "M10 Conduct",
    "L1/2 Cond",
    "L1 Cond",
    "L1 Anti-EBO Conductivity",
    "L1 Anti-EBO Conductivity",
    "UltrasonicWaterConductivity"
);
$nick_col = $DataLog_L1_Conductivity;