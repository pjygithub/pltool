<?
$DataLog_L2_Speed = array(
    "Time",
    "L2 Target Speed",
    "L2 Target  Speed",
    "L2 Running Speed",
    "L2 Standard Speed",
    "L2 Offload Speed",
    "Strand 2 Running Speed",
    "L2 Plating Time",
    "L2 Run Speed",
    "L2 Running Speed",
    "L2 SpeedMeter",
    "L2 Target Speed",
    "L2 Running Speed",
    "L2 SpeedMeter",
    "L2 Running Speed",
    "L2 SpeedMeter",
    "L2 Standard Speed",
    "L2 Target  Speed",
    "L2SpeedRead",
    "L2SpeedSet"
);
$nick_col = $DataLog_L2_Speed;