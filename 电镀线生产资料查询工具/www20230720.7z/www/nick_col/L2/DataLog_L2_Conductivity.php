<?
$DataLog_L2_Conductivity = array(
    "Time",
    "L2 Conductivity",
    "L2 Conductivity",
    "L2/3 Conductivity",
    "M10 Conduct",
    "L2/3 Cond",
    "L2 Cond",
    "L2 Anti-EBO Conductivity",
    "L2 Anti-EBO Conductivity",
    "UltrasonicWaterConductivity"
);
$nick_col = $DataLog_L2_Conductivity;