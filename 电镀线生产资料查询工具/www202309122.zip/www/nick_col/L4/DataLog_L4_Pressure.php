<?
$DataLog_L4_Pressure = array(
    "Time",
    "CompressedAirPressureMeter",
    "CoolingWaterPressureMeter",
    "DIPressureMeter",
    "L0 Ni Strike(1)(In)",
    "L0 Ni Strike(1)(Out)",
    "L0 Ni Strike(2)(In)",
    "L0 Ni Strike(2)(Out)",
    "L0CWPressure",
    "L0DIPressure",
    "L4 Air",
    "M10 AirBlow Inlet",
    "ROPressureMeter",
);
$nick_col = $DataLog_L4_Pressure;
